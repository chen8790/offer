import requests
import json
from concurrent.futures import ThreadPoolExecutor

API_TOKEN = '0TJYG1Sdfhq18xIBCrLHT4GAdKJWDc0vkkDUoUC9'
API_URL_ZONE = 'https://api.cloudflare.com/client/v4/zones'
API_URL_DNS = 'https://api.cloudflare.com/client/v4/zones/{}/dns_records'
ACCOUNT_ID = '5210eefae270f91ab19a5290e4fe1a3c'

HEADERS = {
    'Authorization': f'Bearer {API_TOKEN}',
    'Content-Type': 'application/json'
}
def add_domain_to_cloudflare(domain):
    data = {
        'name': domain,
        'jump_start': True,
        'account': {'id': ACCOUNT_ID}
    }
    try:
        response = requests.post(API_URL_ZONE, json=data, headers=HEADERS)
        response.raise_for_status()
        data = response.json()
        return data['result']['id'] if data['success'] else None
    except requests.exceptions.RequestException:
        return None
def get_ns_records(domain, zone_id):
    try:
        response = requests.get(f'{API_URL_ZONE}/{zone_id}', headers=HEADERS)
        response.raise_for_status()
        zone_data = response.json()
        if zone_data['success']:
            ns_records = zone_data['result']['name_servers']
            print(f"{domain} NS: {', '.join(ns_records)}")
    except requests.exceptions.RequestException:
        print(f"获取 NS 记录失败: {domain}")
def enable_https_redirect(zone_id, domain):
    url = f"{API_URL_ZONE}/{zone_id}/settings/always_use_https"
    data = {"value": "on"}
    try:
        requests.patch(url, headers=HEADERS, json=data)
    except requests.exceptions.RequestException:
        pass
def domain_exists_in_cloudflare(domain):
    url = f"{API_URL_ZONE}?name={domain}"
    try:
        response = requests.get(url, headers=HEADERS)
        response.raise_for_status()
        data = response.json()
        return data['result'][0]['id'] if data['success'] and data['result'] else None
    except requests.exceptions.RequestException:
        return None
def process_domain(domain):
    zone_id = domain_exists_in_cloudflare(domain)
    if not zone_id:
        zone_id = add_domain_to_cloudflare(domain)
        if not zone_id:
            return
    get_ns_records(domain, zone_id)
    enable_https_redirect(zone_id, domain)
def read_domains_from_file(file_path):
    try:
        with open(file_path, 'r') as file:
            return [line.strip() for line in file.readlines() if line.strip()]
    except FileNotFoundError:
        print(f"文件 {file_path} 未找到!")
        return []
def main():
    file_path = 'yu.txt'
    domains = read_domains_from_file(file_path)
    if not domains:
        print("文件没有域名")
        return
    with ThreadPoolExecutor(max_workers=10) as executor:
        executor.map(process_domain, domains)
if __name__ == "__main__":
    main()
