import requests
import concurrent.futures

API_TOKEN = "0TJYG1Sdfhq18xIBCrLHT4GAdKJWDc0vkkDUoUC9"
HEADERS = {
    "Authorization": f"Bearer {API_TOKEN}",
    "Content-Type": "application/json"
}
MAX_WORKERS = 10
def get_all_zones():
    zones = []
    page = 1
    per_page = 50
    while True:
        url = f"https://api.cloudflare.com/client/v4/zones?page={page}&per_page={per_page}"
        response = requests.get(url, headers=HEADERS)
        if response.status_code == 200:
            data = response.json()
            zones.extend([(zone["id"], zone["name"]) for zone in data.get("result", [])])
            if page >= data.get("result_info", {}).get("total_pages", 1):
                break
            page += 1
        else:
            print("获取域名失败:", response.json())
            break
    return zones
def check_https_status(zone_id):
    url = f"https://api.cloudflare.com/client/v4/zones/{zone_id}/settings/always_use_https"
    response = requests.get(url, headers=HEADERS)
    if response.status_code == 200:
        status = response.json().get("result", {}).get("value", "off")
        return status == "on"
    else:
        print(f"检查 HTTPS 状态失败: {response.json()}")
        return None
def enable_https_redirect(zone_info):
    zone_id, domain_name = zone_info
    if check_https_status(zone_id):
        print(f"[跳过] {domain_name} 已开HTTPS，无需修改。")
        return
    url = f"https://api.cloudflare.com/client/v4/zones/{zone_id}/settings/always_use_https"
    data = {"value": "on"}
    response = requests.patch(url, headers=HEADERS, json=data)
    if response.status_code == 200:
        print(f"[成功] {domain_name} 已开启强制跳转HTTPS")
    else:
        print(f"[失败] {domain_name} 设置 HTTPS 失败:", response.json())
def main():
    zones = get_all_zones()
    if not zones:
        print("未找到任何域名，请检查 API 权限。")
        return
    print(f"检测到 {len(zones)} 个域名，开始检查并批量开启 HTTPS 强制跳转...")
    with concurrent.futures.ThreadPoolExecutor(max_workers=MAX_WORKERS) as executor:
        executor.map(enable_https_redirect, zones)
if __name__ == "__main__":
    main()
