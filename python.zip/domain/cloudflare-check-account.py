import requests
import json
from concurrent.futures import ThreadPoolExecutor


CF_API_URL = "https://api.cloudflare.com/client/v4/zones"
def read_domains_from_file(file_path):
    try:
        with open(file_path, 'r') as file:
            domains = file.read().splitlines() 
            return domains
    except FileNotFoundError:
        print(f"文件 {file_path} 没有找到！")
        return []
    except Exception as e:
        print(f"读取文件时发生错误: {e}")
        return []
def read_accounts_from_file(file_path):
    try:
        with open(file_path, 'r') as file:
            accounts = json.load(file) 
            return accounts
    except FileNotFoundError:
        print(f"文件 {file_path} 没有找到！")
        return {}
    except json.JSONDecodeError:
        print(f"文件 {file_path} 格式错误！")
        return {}
def translate_status(status):
    status_mapping = {
        "active": "激活",
        "pending": "等待",
        "moved": "移除",
        "inactive": "非活动",
        "under_maintenance": "维护中",
    }
    return status_mapping.get(status, "未知状态")  
def get_zones(api_email, api_key):
    zones = []
    page = 1
    per_page = 100  
    while True:
        headers = {
            'X-Auth-Email': api_email,  
            'X-Auth-Key': api_key,     
            'Content-Type': 'application/json',
        }
        params = {
            'page': page,      
            'per_page': per_page,
        }
        response = requests.get(CF_API_URL, headers=headers, params=params)
        if response.status_code == 200:
            data = response.json()
            zones.extend(data['result']) 
            if len(data['result']) < per_page:
                break 
            page += 1
        else:
            print(f"API无效 账户邮箱: {api_email}, 错误信息: {response.text}")
            break
    return zones
def find_domain_owner_and_status(domain, accounts):
    print(f"查询域名: {domain}...")
    found_accounts = []  
    for account, credentials in accounts.items():
        zones = get_zones(credentials['email'], credentials['api_key'])
        for zone in zones:
            if domain == zone['name']:
                status = zone.get('status', 'Unknown')
                status_chinese = translate_status(status)
                found_accounts.append((account, status_chinese))
    return domain, found_accounts
def query_domain(domain, accounts):
    return find_domain_owner_and_status(domain, accounts)
def sort_and_print_results(results):
    status_priority = {
        "激活": 1,
        "等待": 2,
        "移除": 2,
        "非活动": 3,
        "维护中": 3,
        "未知状态": 3
    }
    sorted_results = sorted(results, key=lambda x: (
        [status_priority[status] for account, status in x[1]] if x[1] else [999]), reverse=False)
    for domain, found_accounts in sorted_results:
        if found_accounts:
            if len(found_accounts) > 1:
                print(f"{domain} 在多个账户出现：")
                for account, status in found_accounts:
                    print(f"{account} - 状态: {status}")
            else:
                account, status = found_accounts[0]
                print(f"{domain}: {account}，状态: {status}")
        else:
            print(f"{domain} 没找到。")
if __name__ == '__main__':
    domains_to_check = read_domains_from_file('yu.txt')
    accounts = read_accounts_from_file('accounts.json')
    if not domains_to_check:
        print("yu文件中没有域名")
    elif not accounts:
        print("文件中没有账号信息")
    else:
        with ThreadPoolExecutor(max_workers=10) as executor:
            results = list(executor.map(lambda domain: query_domain(domain, accounts), domains_to_check))
            sort_and_print_results(results)

