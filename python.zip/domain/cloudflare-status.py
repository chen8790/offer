import requests
from concurrent.futures import ThreadPoolExecutor

API_TOKEN = '0TJYG1Sdfhq18xIBCrLHT4GAdKJWDc0vkkDUoUC9'
API_URL = 'https://api.cloudflare.com/client/v4/zones'

headers = {
    'Authorization': f'Bearer {API_TOKEN}',
    'Content-Type': 'application/json',
}
def check_domain_status(domain):
    params = {
        'name': domain
    } 
    response = requests.get(API_URL, headers=headers, params=params)
    
    if response.status_code == 200:
        data = response.json()
        if data['result']:
            zone = data['result'][0]
            status = zone.get('status', 'unknown')
            if status == 'active':
                return f"{domain}: 激活"
            elif status == 'pending':
                return f"{domain}: 等待"
            elif status == 'deleted' or status == 'moved':
                return f"{domain}: 移除"
            else:
                return f"{domain}: 状态未知"
        else:
            return f"{domain}: 不在当前企业账号"
    else:
        return f"{domain}: 查询出错, 错误代码 {response.status_code}"
def read_domains_from_file(file_path):
    with open(file_path, 'r') as file:
        domains = [line.strip() for line in file.readlines() if line.strip()]
    return domains
def process_domains_concurrently(domains):
    with ThreadPoolExecutor(max_workers=10) as executor:
        results = list(executor.map(check_domain_status, domains))
    return results
if __name__ == "__main__":
    domains = read_domains_from_file('yu.txt')
    results = process_domains_concurrently(domains)
    for result in results:
        print(result)

