import requests
from concurrent.futures import ThreadPoolExecutor

CLOUDFLARE_API_TOKEN = "0TJYG1Sdfhq18xIBCrLHT4GAdKJWDc0vkkDUoUC9"
API_BASE_URL = "https://api.cloudflare.com/client/v4"
HEADERS = {
    "Authorization": f"Bearer {CLOUDFLARE_API_TOKEN}",
    "Content-Type": "application/json"
}
def load_domains_from_file(file_path):
    try:
        with open(file_path, "r") as file:
            domains = [line.strip() for line in file if line.strip()]
        if not domains:
            print("文件为空，没读取到任何域名")
        return domains
    except FileNotFoundError:
        print(f"文件 {file_path} 没找到")
        return []
def get_zone_id(domain):
    url = f"{API_BASE_URL}/zones?name={domain}"
    response = requests.get(url, headers=HEADERS)
    data = response.json()
    if not data.get("success"):
        return None
    if not data.get("result"):
        return None
    return data["result"][0]["id"]
def delete_domain_from_cloudflare(domain):
    zone_id = get_zone_id(domain)
    if not zone_id:
        return False
    url = f"{API_BASE_URL}/zones/{zone_id}"
    response = requests.delete(url, headers=HEADERS)
    data = response.json()
    if data.get("success"):
        return True
    else:
        return False
domains = load_domains_from_file("yu.txt")
if domains:
    confirm = input(f"你确定一定以及肯定要删除文件中的 {len(domains)} 个域名吗? 按 'y' 确认删除所有域名，其他键取消: ")
    if confirm.lower() == 'y':
        success_domains = []
        failed_domains = []
        with ThreadPoolExecutor() as executor:
            results = executor.map(delete_domain_from_cloudflare, domains)
            for domain, result in zip(domains, results):
                if result:
                    success_domains.append(domain)
                else:
                    failed_domains.append(domain)
        if success_domains:
            print("这些域名删掉了:")
            for domain in success_domains:
                print(f"  {domain}")
        if failed_domains:
            print("这些域名没删掉:")
            for domain in failed_domains:
                print(f"  {domain}")
    else:
        print("取消操作")
else:
    print("文件里没有域名")
