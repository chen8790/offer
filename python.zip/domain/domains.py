import requests
from concurrent.futures import ThreadPoolExecutor

API_KEY = 'bc742b276e2509ccc9a4ca4310de7da0d3a0a'
EMAIL = 'chenhaisheng008@gmail.com'
ZONE_API_URL = 'https://api.cloudflare.com/client/v4/zones'

def read_domains_from_file(file_path):
    with open(file_path, 'r') as file:
        domains = [line.strip() for line in file.readlines() if line.strip()]
    return domains
def get_cloudflare_zones():
    headers = {
        'X-Auth-Email': EMAIL,
        'X-Auth-Key': API_KEY,
        'Content-Type': 'application/json',
    }
    cloudflare_zones = set()
    page = 1 
    while True:
        params = {'page': page, 'per_page': 100}  
        response = requests.get(ZONE_API_URL, headers=headers, params=params)
        if response.status_code == 200:
            data = response.json()
            zones = data['result']
            if not zones: 
                break
            for zone in zones:
                cloudflare_zones.add(zone['name'])
            page += 1 
        else:
            print("Error: {}, {}".format(response.status_code, response.text))
            break
    return cloudflare_zones
def normalize_domain(domain):
    if domain.startswith('www.'):
        return domain[4:] 
    return domain
def check_domain(domain, cloudflare_zones):
    normalized_domain = normalize_domain(domain) 
    if normalized_domain in cloudflare_zones:
        print(f"{domain} ——————>>> 在当前自用账号中")
    else:
        print(f"{domain} ------>>> 不在当前自用账号中")
def main():
    domains = read_domains_from_file('yu.txt') 
    cloudflare_zones = get_cloudflare_zones() 
    with ThreadPoolExecutor(max_workers=10) as executor: 
        for domain in domains:
            executor.submit(check_domain, domain, cloudflare_zones)  
if __name__ == '__main__':
    main()
