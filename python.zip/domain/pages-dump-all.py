import requests
from concurrent.futures import ThreadPoolExecutor

API_TOKEN = "0TJYG1Sdfhq18xIBCrLHT4GAdKJWDc0vkkDUoUC9"
ACCOUNT_ID = "5210eefae270f91ab19a5290e4fe1a3c"

PROJECT_NAME = input("输入喜爱福 Pages 名称: ")
headers = {
    "Authorization": f"Bearer {API_TOKEN}",
    "Content-Type": "application/json"
}
def fetch_project_domains_page(account_id, project_name, page):
    url = f"https://api.cloudflare.com/client/v4/accounts/{account_id}/pages/projects/{project_name}/domains?page={page}&per_page=20"
    response = requests.get(url, headers=headers)
    
    if response.status_code == 200:
        data = response.json()
        if "result" in data:
            return [domain_data.get("name", None) for domain_data in data["result"]]
        else:
            return []
    else:
        print(f"请求失败，状态码: {response.status_code}")
        print(response.text)
        return []
def get_all_domains(account_id, project_name):
    domains = []
    page = 1
    all_domains = []
    while True:
        with ThreadPoolExecutor(max_workers=5) as executor:
            result = executor.submit(fetch_project_domains_page, account_id, project_name, page)
            page_domains = result.result()
            all_domains.extend(page_domains)
        
        if page_domains:
            page += 1
        else:
            break
    return all_domains
def save_domains_to_file(domains):
    with open("download.txt", "w") as file:
        if domains:
            for domain in domains:
                file.write(domain + "\n")
            print(f"拢共获取到 {len(domains)} 个域名，已写入 download.txt")
        else:
            file.write("没有绑定的域名.\n")
            print("没有绑定的域名.")
def main():
    domains = get_all_domains(ACCOUNT_ID, PROJECT_NAME)
    save_domains_to_file(domains)
if __name__ == "__main__":
    main()

