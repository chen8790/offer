import requests
from concurrent.futures import ThreadPoolExecutor, as_completed

API_TOKEN = "0TJYG1Sdfhq18xIBCrLHT4GAdKJWDc0vkkDUoUC9"
ACCOUNT_ID = "5210eefae270f91ab19a5290e4fe1a3c"

PROJECT_NAME = input("输入喜爱福 Pages 名称: ")
headers = {
    "Authorization": f"Bearer {API_TOKEN}",
    "Content-Type": "application/json"
}
def fetch_page_domains(page, account_id, project_name):
    url = f"https://api.cloudflare.com/client/v4/accounts/{account_id}/pages/projects/{project_name}/domains?page={page}&per_page=20"
    domains = [] 
    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        data = response.json()
        if "result" in data:
            for domain_data in data["result"]:
                domain = domain_data.get("name", None)
                status = domain_data.get("status", None)
                if domain and status not in ['active', 'pending'] and not domain.startswith('www.'):
                    domains.append(domain)
    return domains
def get_project_domains(account_id, project_name):
    url = f"https://api.cloudflare.com/client/v4/accounts/{account_id}/pages/projects/{project_name}/domains"
    response = requests.get(url, headers=headers)
    if response.status_code == 200:
        data = response.json()
        total_pages = data["result_info"]["total_pages"]
    else:
        print(f"请求失败，状态码: {response.status_code}")
        print(response.text)
        return
    domains = []
    with ThreadPoolExecutor(max_workers=5) as executor:
        futures = []
        for page in range(1, total_pages + 1):
            futures.append(executor.submit(fetch_page_domains, page, account_id, project_name))
        for future in as_completed(futures):
            domains.extend(future.result())
    with open("error.txt", "w") as file:
        if domains:
            for domain in domains:
                file.write(domain + "\n")
            print(f"获取到 {len(domains)} 个挂逼域名，已写入 error.txt 文件.")
        else:
            file.write("没有挂逼的域名.\n")
            print("没有挂逼的域名.")
get_project_domains(ACCOUNT_ID, PROJECT_NAME)

