import requests
import concurrent.futures

API_TOKEN = "0TJYG1Sdfhq18xIBCrLHT4GAdKJWDc0vkkDUoUC9"
ACCOUNT_ID = "5210eefae270f91ab19a5290e4fe1a3c"
PROJECT_NAME = input("输入喜爱福 Pages 名称（主域名不要超过25个）：")

HEADERS = {
    "Authorization": f"Bearer {API_TOKEN}",
    "Content-Type": "application/json"
}
def read_domains(filename):
    try:
        with open(filename, "r") as file:
            return [line.strip() for line in file if line.strip()]
    except FileNotFoundError:
        return []
def get_zone_id(domain):
    url = f"https://api.cloudflare.com/client/v4/zones?name={domain}"
    response = requests.get(url, headers=HEADERS).json()
    return response["result"][0]["id"] if response.get("success") and response["result"] else None
def get_pages_domains():
    url = f"https://api.cloudflare.com/client/v4/accounts/{ACCOUNT_ID}/pages/projects/{PROJECT_NAME}/domains"
    response = requests.get(url, headers=HEADERS).json()
    return {entry["name"] for entry in response.get("result")} if response.get("success") else set()
def get_existing_cname(zone_id, domain):
    url = f"https://api.cloudflare.com/client/v4/zones/{zone_id}/dns_records?name={domain}&type=CNAME"
    response = requests.get(url, headers=HEADERS).json()
    return response["result"][0] if response.get("success") and response["result"] else None
def delete_dns_record(zone_id, record_id):
    url = f"https://api.cloudflare.com/client/v4/zones/{zone_id}/dns_records/{record_id}"
    requests.delete(url, headers=HEADERS)
def add_dns_record(domain, zone_id):
    cname_target = f"{PROJECT_NAME}.pages.dev"
    existing_record = get_existing_cname(zone_id, domain)
    if existing_record:
        if existing_record["content"] == cname_target:
            return True
        else:
            delete_dns_record(zone_id, existing_record["id"])
    url = f"https://api.cloudflare.com/client/v4/zones/{zone_id}/dns_records"
    data = {"type": "CNAME", "name": domain, "content": cname_target, "ttl": 1, "proxied": True}
    return requests.post(url, json=data, headers=HEADERS).json().get("success")
def add_custom_domain(domain):
    url = f"https://api.cloudflare.com/client/v4/accounts/{ACCOUNT_ID}/pages/projects/{PROJECT_NAME}/domains"
    return requests.post(url, json={"name": domain}, headers=HEADERS).json().get("success")
def process_domain(domain, pages_domains):
    zone_id = get_zone_id(domain)
    if not zone_id:
        print(f"❌ {domain} 添加失败")
        return
    success = True
    for subdomain in [domain, f"www.{domain}"]:
        if subdomain not in pages_domains:
            if not add_custom_domain(subdomain):
                success = False
        if not add_dns_record(subdomain, zone_id):
            success = False 
    print(f"✅ {domain} 添加成功" if success else f"❌ {domain} 添加失败")
if __name__ == "__main__":
    domain_list = read_domains("yu.txt")
    if not domain_list:
        print("❌ 文件中没有域名，程序终止。")
    else:
        pages_domains = get_pages_domains()
        with concurrent.futures.ThreadPoolExecutor(max_workers=10) as executor:
            executor.map(lambda domain: process_domain(domain, pages_domains), domain_list)
