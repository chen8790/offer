import requests
import concurrent.futures

API_TOKEN = "0TJYG1Sdfhq18xIBCrLHT4GAdKJWDc0vkkDUoUC9"
ACCOUNT_ID = "5210eefae270f91ab19a5290e4fe1a3c"
PROJECT_NAME = input("请输入你的喜爱福 Pages 名称-主域名不要超过25个: ")

HEADERS = {
    "Authorization": f"Bearer {API_TOKEN}",
    "Content-Type": "application/json"
}
def read_domains(filename):
    with open(filename, "r") as file:
        domains = [line.strip() for line in file.readlines() if line.strip()]
    return domains
def get_zone_id(domain):
    url = f"https://api.cloudflare.com/client/v4/zones?name={domain}"
    try:
        response = requests.get(url, headers=HEADERS).json()
        if response.get("success") and response["result"]:
            return response["result"][0]["id"]
        else:
            print(f"❌ 获取 {domain} 的 Zone ID 失败: {response}")
    except Exception as e:
        print(f"❌ 请求 Zone ID 时出现错误: {e}")
    return None
def get_dns_records(zone_id):
    url = f"https://api.cloudflare.com/client/v4/zones/{zone_id}/dns_records"
    try:
        response = requests.get(url, headers=HEADERS).json()
        if response.get("success"):
            return response["result"]
        else:
            print(f"❌ 获取 DNS 记录失败: {response}")
    except Exception as e:
        print(f"❌ 请求获取 DNS 记录时出现错误: {e}")
    return []
def delete_dns_record(zone_id, dns_record_id):
    url = f"https://api.cloudflare.com/client/v4/zones/{zone_id}/dns_records/{dns_record_id}"
    try:
        response = requests.delete(url, headers=HEADERS).json()
        if response.get("success"):
            print(f"✅ 删除 DNS 记录成功: {dns_record_id}")
        else:
            print(f"❌ 删除 DNS 记录失败: {response}")
    except Exception as e:
        print(f"❌ 请求删除 DNS 记录时出现错误: {e}")
def add_custom_domain(domain):
    url = f"https://api.cloudflare.com/client/v4/accounts/{ACCOUNT_ID}/pages/projects/{PROJECT_NAME}/domains"
    data = {"name": domain}
    try:
        response = requests.post(url, json=data, headers=HEADERS).json()
        if response.get("success"):
            return response
        else:
            print(f"❌ 绑定 {domain} 到项目失败: {response}")
    except Exception as e:
        print(f"❌ 请求添加自定义域时出现错误: {e}")
    return None
def add_dns_record(domain, zone_id):
    url = f"https://api.cloudflare.com/client/v4/zones/{zone_id}/dns_records"
    data = {
        "type": "CNAME",
        "name": domain,
        "content": f"{PROJECT_NAME}.pages.dev",
        "ttl": 1,
        "proxied": True
    }
    try:
        response = requests.post(url, json=data, headers=HEADERS).json()
        if response.get("success"):
            return response
        else:
            print(f"❌ 添加 {domain} 的 CNAME 解析失败: {response}")
    except Exception as e:
        print(f"❌ 请求添加 DNS 记录时出现错误: {e}")
    return None

def delete_all_dns_records(zone_id):
    existing_records = get_dns_records(zone_id)
    for record in existing_records:
        if record["type"] == "CNAME":
            delete_dns_record(zone_id, record["id"])
def process_domains_for_deletion(domain_list, error_file):
    for domain in domain_list:
        print(f"🔍 获取 {domain} 的 Zone ID...")
        zone_id = get_zone_id(domain)
        if zone_id:
            delete_all_dns_records(zone_id)
        else:
            error_file.write(f"❌ 跳过 {domain}，没有对应的 Zone ID！\n")
def process_domains_for_addition(domain_list, error_file):
    for domain in domain_list:
        print(f"🔍 获取 {domain} 的 Zone ID...")
        zone_id = get_zone_id(domain)
        if not zone_id:
            print(f"❌ 跳过 {domain}，没有对应的 Zone ID！")
            error_file.write(f"❌ 跳过 {domain}，没有对应的 Zone ID！\n")
            continue
        for subdomain in [domain, f"www.{domain}"]:
            print(f"🚀 正在绑定 {subdomain} 到  ({PROJECT_NAME})...")
            response = add_custom_domain(subdomain)
            if not response:
                print(f"❌ 绑定 {subdomain} 失败！")
                error_file.write(f"❌ 绑定 {subdomain} 失败！\n")
                continue
            print(f"✅ 绑定结果: {response}")

            print(f"🌍 正在添加 {subdomain} 的 CNAME 解析...")
            dns_response = add_dns_record(subdomain, zone_id)
            if not dns_response:
                print(f"❌ 添加 DNS 记录 {subdomain} 失败！")
                error_file.write(f"❌ 添加 DNS 记录 {subdomain} 失败！\n")
                continue
            print(f"✅ DNS 记录添加成功: {dns_response}")

if __name__ == "__main__":
    domain_list = read_domains("yu.txt")
    
    MAX_THREADS = 10  # 最大并发线程数嫌慢可以改大，挂逼活该

    with open("error.txt", "w") as error_file: 
        with concurrent.futures.ThreadPoolExecutor(max_workers=MAX_THREADS) as executor:
            executor.map(lambda domain: process_domains_for_deletion([domain], error_file), domain_list)
        with concurrent.futures.ThreadPoolExecutor(max_workers=MAX_THREADS) as executor:
            executor.map(lambda domain: process_domains_for_addition([domain], error_file), domain_list)

